package com.wordpop.kids.v2.data

import com.wordpop.kids.v2.model.WordCategory
import com.wordpop.kids.v2.model.WordItem

object WordRepository {

    private val animals = listOf(
        WordItem("Dog", "🐶", "A dog loves to wag its tail!", "Con chó", "I bark 'woof' and love to wag my tail.", "Tớ sủa gâu gâu và hay vẫy đuôi mừng chủ.", WordCategory.ANIMALS),
        WordItem("Cat", "🐱", "A cat says meow and likes to nap.", "Con mèo", "I say 'meow' and chase little mice.", "Tớ kêu meo meo và thích bắt chuột.", WordCategory.ANIMALS),
        WordItem("Cow", "🐮", "A cow eats grass and gives us milk.", "Con bò", "I live on a farm and give fresh milk.", "Tớ sống ở nông trại và cho sữa tươi.", WordCategory.ANIMALS),
        WordItem("Pig", "🐷", "A pink pig says oink in the mud.", "Con heo", "I am pink, say 'oink', and have a curly tail.", "Tớ có màu hồng và chiếc đuôi xoăn nhỏ.", WordCategory.ANIMALS),
        WordItem("Duck", "🦆", "A duck swims in the pond and says quack.", "Con vịt", "I swim in the pond and say 'quack quack'.", "Tớ bơi dưới ao và kêu cạp cạp.", WordCategory.ANIMALS),
        WordItem("Frog", "🐸", "A green frog jumps high on a lily pad.", "Con ếch", "I am green, jump high, and love the rain.", "Tớ màu xanh lá, nhảy rất cao và thích trời mưa.", WordCategory.ANIMALS),
        WordItem("Lion", "🦁", "A lion is strong and lets out a big roar!", "Con sư tử", "I have a big fluffy mane and a loud roar.", "Tớ có bờm lớn và tiếng gầm vang rừng.", WordCategory.ANIMALS),
        WordItem("Tiger", "🐯", "A tiger has orange fur with black stripes.", "Con hổ", "I am a big orange cat with black stripes.", "Tớ có bộ lông cam với những vằn đen.", WordCategory.ANIMALS),
        WordItem("Bear", "🐻", "A big bear loves sweet honey and berries.", "Con gấu", "I am big, furry, and love sweet honey.", "Tớ to lớn, nhiều lông và rất thích mật ong.", WordCategory.ANIMALS),
        WordItem("Monkey", "🐵", "A monkey swings in trees and eats bananas.", "Con khỉ", "I swing on tree branches and love bananas.", "Tớ leo trèo trên cây và thích ăn chuối.", WordCategory.ANIMALS),
        WordItem("Elephant", "🐘", "An elephant has huge ears and a long trunk.", "Con voi", "I am huge and spray water with my long trunk.", "Tớ rất to lớn và có chiếc vòi dài.", WordCategory.ANIMALS),
        WordItem("Giraffe", "🦒", "A giraffe has a very long neck for tall trees.", "Con hươu cao cổ", "I have the longest neck to eat high leaves.", "Tớ có cái cổ dài nhất để ăn lá trên cao.", WordCategory.ANIMALS),
        WordItem("Rabbit", "🐰", "A rabbit has long ears and hops fast.", "Con thỏ", "I have two long ears and love crunchy carrots.", "Tớ có đôi tai dài và thích ăn cà rốt.", WordCategory.ANIMALS),
        WordItem("Mouse", "🐭", "A tiny mouse squeaks and nibbles cheese.", "Con chuột", "I am very tiny, say 'squeak', and love cheese.", "Tớ rất nhỏ bé và thích gặm phô mai.", WordCategory.ANIMALS),
        WordItem("Bird", "🐦", "A little bird flaps its wings and sings.", "Con chim", "I have feathers, fly in the sky, and sing.", "Tớ có cánh bay trên trời và thích hót.", WordCategory.ANIMALS),
        WordItem("Fish", "🐟", "A fish swims happily under the water.", "Con cá", "I have fins and live underwater all day.", "Tớ có vây và bơi lội dưới nước.", WordCategory.ANIMALS),
        WordItem("Turtle", "🐢", "A turtle walks slowly with a shell on its back.", "Con rùa", "I walk slowly and carry my hard shell home.", "Tớ đi chậm và mang chiếc mai cứng trên lưng.", WordCategory.ANIMALS),
        WordItem("Whale", "🐳", "A giant whale swims in the deep blue ocean.", "Con cá voi", "I am the biggest animal swimming in the ocean.", "Tớ là loài vật lớn nhất bơi ngoài đại dương.", WordCategory.ANIMALS),
        WordItem("Bee", "🐝", "A busy bee buzzes and makes sweet honey.", "Con ong", "I am yellow and black, buzz, and make honey.", "Tớ có sọc vàng đen, kêu vo ve và làm mật.", WordCategory.ANIMALS),
        WordItem("Butterfly", "🦋", "A butterfly has colorful wings and visits flowers.", "Con bướm", "I have bright colorful wings and dance on flowers.", "Tớ có đôi cánh sặc sỡ hay đậu trên hoa.", WordCategory.ANIMALS)
    )

    private val vehicles = listOf(
        WordItem("Car", "🚗", "A car has four wheels and drives on the road.", "Chiếc xe hơi", "I have four wheels and take your family on trips.", "Tớ có bốn bánh và chở gia đình đi chơi.", WordCategory.VEHICLES),
        WordItem("Bus", "🚌", "A big bus carries many people to school.", "Chiếc xe buýt", "I am long and carry lots of kids to school.", "Tớ to dài và chở rất nhiều bạn nhỏ đi học.", WordCategory.VEHICLES),
        WordItem("Truck", "🚚", "A strong truck carries heavy boxes.", "Chiếc xe tải", "I am big and carry heavy boxes across town.", "Tớ rất khỏe và chở nhiều thùng hàng nặng.", WordCategory.VEHICLES),
        WordItem("Train", "🚂", "A train rides fast on iron tracks.", "Đoàn tàu hỏa", "I say 'choo-choo' and roll on long metal tracks.", "Tớ chạy trên đường ray sắt và kêu tu tu.", WordCategory.VEHICLES),
        WordItem("Bike", "🚲", "You pedal a bike with your two feet.", "Chiếc xe đạp", "I have two wheels and you pedal me with your feet.", "Tớ có hai bánh và bé đạp bằng chân.", WordCategory.VEHICLES),
        WordItem("Plane", "✈️", "A plane flies high above the white clouds.", "Chiếc máy bay", "I have big wings and fly high above the clouds.", "Tớ có đôi cánh lớn bay cao trên mây.", WordCategory.VEHICLES),
        WordItem("Boat", "⛵", "A sailboat glides on the lake with the wind.", "Chiếc thuyền buồm", "I float on water and catch the wind with my sail.", "Tớ lướt trên mặt nước nhờ cánh buồm đón gió.", WordCategory.VEHICLES),
        WordItem("Ship", "🚢", "A huge ship sails across the big ocean.", "Con tàu thủy", "I am much bigger than a boat and cross the ocean.", "Tớ to lớn hơn thuyền và vượt đại dương.", WordCategory.VEHICLES),
        WordItem("Taxi", "🚕", "A yellow taxi drives passengers around the city.", "Chiếc xe taxi", "I am a city car you can wave at for a ride.", "Tớ là chiếc xe chở khách chạy khắp thành phố.", WordCategory.VEHICLES),
        WordItem("Police Car", "🚓", "A police car flashes lights to keep us safe.", "Xe cảnh sát", "I flash blue and red lights to help keep people safe.", "Tớ có đèn nhấp nháy giúp bảo vệ mọi người.", WordCategory.VEHICLES),
        WordItem("Fire Truck", "🚒", "A red fire truck rushes to put out fires!", "Xe cứu hỏa", "I am bright red, carry a ladder, and put out fires.", "Tớ màu đỏ, có thang dài và giúp dập lửa.", WordCategory.VEHICLES),
        WordItem("Ambulance", "🚑", "An ambulance helps sick people get to the hospital.", "Xe cứu thương", "I hurry to help people get to the doctor safely.", "Tớ chở người bệnh đến bệnh viện thật nhanh.", WordCategory.VEHICLES),
        WordItem("Tractor", "🚜", "A tractor has giant wheels to work on the farm.", "Xe máy kéo", "I have giant wheels and help farmers in the field.", "Tớ có bánh xe khổng lồ giúp bác nông dân.", WordCategory.VEHICLES),
        WordItem("Rocket", "🚀", "A rocket blasts off all the way to space!", "Tên lửa", "I count down 3-2-1 and blast off into outer space.", "Tớ phóng vút lên bầu trời bay vào vũ trụ.", WordCategory.VEHICLES),
        WordItem("Helicopter", "🚁", "A helicopter spins its top blades to fly up.", "Máy bay trực thăng", "I fly with giant spinning blades on top of my roof.", "Tớ có cánh quạt quay tít trên đỉnh để bay thẳng lên.", WordCategory.VEHICLES),
        WordItem("Scooter", "🛴", "You push a scooter with one foot to zoom!", "Xe trượt scooter", "You stand on me and push with one foot to glide.", "Bé đứng trên tớ và đẩy bằng một chân để trượt.", WordCategory.VEHICLES),
        WordItem("Motorcycle", "🏍️", "A motorcycle has two wheels and a fast engine.", "Chiếc xe máy", "I have two wheels like a bike, but an engine makes me zoom.", "Tớ có hai bánh nhưng chạy rất nhanh nhờ động cơ.", WordCategory.VEHICLES),
        WordItem("Subway", "🚇", "A subway train zooms through underground tunnels.", "Tàu điện ngầm", "I am a fast city train that travels underground.", "Tớ là tàu điện chạy trong đường hầm dưới lòng đất.", WordCategory.VEHICLES),
        WordItem("Van", "🚐", "A roomy van has lots of seats for everyone.", "Xe van gia đình", "I am taller than a car with extra seats inside.", "Tớ rộng rãi hơn xe hơi và có nhiều ghế ngồi.", WordCategory.VEHICLES),
        WordItem("Canoe", "🛶", "You paddle a canoe smoothly down the river.", "Chiếc xuồng", "I am a narrow boat you move using a wooden paddle.", "Tớ là chiếc thuyền nhỏ dùng mái chèo để bơi.", WordCategory.VEHICLES)
    )

    private val familyStuff = listOf(
        WordItem("Bed", "🛏️", "A cozy bed is where you sleep at night.", "Cái giường", "You lie under a blanket on me to sleep at night.", "Bé nằm đắp chăn ngủ ngon trên tớ mỗi tối.", WordCategory.FAMILY_STUFF),
        WordItem("Chair", "🪑", "You sit on a chair at the dinner table.", "Cái ghế", "I have four legs and you sit on me at the table.", "Tớ có bốn chân để bé ngồi học hoặc ăn cơm.", WordCategory.FAMILY_STUFF),
        WordItem("Couch", "🛋️", "The whole family sits together on the soft couch.", "Ghế sô-pha", "I am a big soft seat in the living room for everyone.", "Tớ là chiếc ghế êm ái trong phòng khách cho cả nhà.", WordCategory.FAMILY_STUFF),
        WordItem("Clock", "⏰", "A clock ticks and tells us what time it is.", "Cái đồng hồ", "I say 'tick-tock' and show you what time it is.", "Tớ kêu tích tắc và báo cho bé biết mấy giờ.", WordCategory.FAMILY_STUFF),
        WordItem("Lamp", "💡", "A bright lamp lights up the room when it's dark.", "Cái đèn", "Switch me on to make a dark room bright.", "Bật tớ lên thì căn phòng tối sẽ sáng bừng.", WordCategory.FAMILY_STUFF),
        WordItem("Book", "📖", "Open a book to read a fun story!", "Quyển sách", "I have paper pages full of stories and pictures.", "Tớ có nhiều trang giấy chứa truyện và tranh vẽ.", WordCategory.FAMILY_STUFF),
        WordItem("Cup", "🥤", "You drink water or juice from a cup.", "Cái cốc / Cái ly", "Pour water or juice into me when you are thirsty.", "Bé rót nước hoặc sữa vào tớ để uống.", WordCategory.FAMILY_STUFF),
        WordItem("Spoon", "🥄", "You scoop warm soup with a spoon.", "Cái muỗng / Cái thìa", "I am round at the tip so you can scoop up soup.", "Tớ dùng để múc canh và cơm thật gọn.", WordCategory.FAMILY_STUFF),
        WordItem("Fork", "🍴", "You pick up noodles or fruit with a fork.", "Cái nĩa", "I have little prongs to pick up fruit or pasta.", "Tớ có các răng nhỏ giúp bé xiên trái cây hoặc mì.", WordCategory.FAMILY_STUFF),
        WordItem("Plate", "🍽️", "Yummy food goes on a clean plate.", "Cái đĩa", "I am flat and round, and hold your dinner.", "Tớ tròn và phẳng, dùng để đựng thức ăn.", WordCategory.FAMILY_STUFF),
        WordItem("Key", "🔑", "Turn the key to unlock the front door.", "Cái chìa khóa", "I am small and metal, and I unlock doors.", "Tớ nhỏ bằng kim loại, dùng để mở khóa cửa.", WordCategory.FAMILY_STUFF),
        WordItem("Door", "🚪", "Knock on the door before you walk inside.", "Cánh cửa", "You open me to walk into a room and close me behind you.", "Bé mở tớ ra để bước vào phòng.", WordCategory.FAMILY_STUFF),
        WordItem("Window", "🪟", "Look out the window to see the sunny sky.", "Cái cửa sổ", "I am made of glass so you can look outside.", "Tớ bằng kính để bé nhìn ra bầu trời bên ngoài.", WordCategory.FAMILY_STUFF),
        WordItem("Phone", "📱", "Mom and Dad call grandma on the phone.", "Chiếc điện thoại", "You use me to call family and hear their voices.", "Dùng tớ để gọi điện nói chuyện với ông bà.", WordCategory.FAMILY_STUFF),
        WordItem("TV", "📺", "We watch cartoons together on the TV.", "Cái ti-vi", "I have a big screen in the living room for cartoons.", "Tớ có màn hình lớn để cả nhà xem phim hoạt hình.", WordCategory.FAMILY_STUFF),
        WordItem("Mirror", "🪞", "Smile at the mirror and see yourself smile back!", "Cái gương", "When you look at me, I show your smiling face.", "Khi bé nhìn vào tớ, bé sẽ thấy khuôn mặt mình cười.", WordCategory.FAMILY_STUFF),
        WordItem("Soap", "🧼", "Wash your hands with bubbly soap before eating.", "Cục xà phòng", "Mix me with water to make bubbles and clean your hands.", "Tớ tạo nhiều bọt giúp rửa sạch đôi tay bé.", WordCategory.FAMILY_STUFF),
        WordItem("Toothbrush", "🪥", "Brush your teeth clean with a toothbrush every night.", "Bàn chải đánh răng", "Use me every morning and night to keep your teeth sparkly.", "Dùng tớ mỗi sáng và tối để răng bé luôn sạch bóng.", WordCategory.FAMILY_STUFF),
        WordItem("Broom", "🧹", "A broom sweeps dust off the floor.", "Cái chổi", "I have a long handle and sweep crumbs off the floor.", "Tớ có cán dài giúp quét sạch bụi trên sàn nhà.", WordCategory.FAMILY_STUFF),
        WordItem("Backpack", "🎒", "Pack your books inside your school backpack.", "Cái ba-lô", "You wear me on your back to carry books to school.", "Bé đeo tớ trên vai để đựng sách vở đi học.", WordCategory.FAMILY_STUFF)
    )

    fun wordsFor(category: WordCategory): List<WordItem> = when (category) {
        WordCategory.ANIMALS -> animals
        WordCategory.VEHICLES -> vehicles
        WordCategory.FAMILY_STUFF -> familyStuff
    }

    fun allWords(): List<WordItem> = animals + vehicles + familyStuff
}
