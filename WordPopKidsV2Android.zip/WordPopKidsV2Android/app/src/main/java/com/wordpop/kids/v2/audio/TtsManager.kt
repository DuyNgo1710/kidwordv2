package com.wordpop.kids.v2.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class TtsManager(context: Context) {
    private var tts: TextToSpeech? = null
    private var isReady = false
    private var pendingUtterance: Pair<String, Boolean>? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val res = tts?.setLanguage(Locale.US)
                isReady = res != TextToSpeech.LANG_MISSING_DATA &&
                          res != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setPitch(1.08f)
                pendingUtterance?.let { (text, slow) -> speak(text, slow) }
                pendingUtterance = null
            }
        }
    }

    fun speak(text: String, slowMode: Boolean) {
        if (!isReady) {
            pendingUtterance = text to slowMode
            return
        }
        tts?.setSpeechRate(if (slowMode) 0.78f else 1.0f)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "wp2_${System.nanoTime()}")
    }

    fun stop() {
        pendingUtterance = null
        tts?.stop()
    }

    fun shutdown() {
        pendingUtterance = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
