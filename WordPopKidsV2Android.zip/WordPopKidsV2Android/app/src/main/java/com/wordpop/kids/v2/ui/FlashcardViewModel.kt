package com.wordpop.kids.v2.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.wordpop.kids.v2.data.WordRepository
import com.wordpop.kids.v2.model.LogicMode
import com.wordpop.kids.v2.model.LogicPuzzle
import com.wordpop.kids.v2.model.WordCategory
import com.wordpop.kids.v2.model.WordItem

enum class ScreenMode { HOME, QUIZ, LOGIC, SETTINGS, SUMMARY }

data class WordPopUiState(
    val screen: ScreenMode = ScreenMode.HOME,
    val previousScreen: ScreenMode = ScreenMode.HOME,
    val readAloudEnabled: Boolean = true,
    val slowMode: Boolean = true,
    val autoBilingualVn: Boolean = false,
    val showVnOnCurrent: Boolean = false,
    // Flashcard Quiz
    val category: WordCategory? = null,
    val deck: List<WordItem> = emptyList(),
    val currentIndex: Int = 0,
    val options: List<WordItem> = emptyList(),
    val answeredCorrectly: Boolean = false,
    val wrongChoices: Set<String> = emptySet(),
    val stars: Int = 0,
    val feedbackText: String = "What is this? Pick the right word!",
    val bestStars: Map<WordCategory, Int> = emptyMap(),
    // Logic Play
    val logicMode: LogicMode? = null,
    val logicPuzzles: List<LogicPuzzle> = emptyList(),
    val logicIndex: Int = 0,
    val logicAnswered: Boolean = false,
    val logicWrongChoices: Set<String> = emptySet(),
    val logicStars: Int = 0,
    val logicFeedback: String = "Think carefully and pick your answer!",
    // Summary
    val summaryTitle: String = "",
    val summaryStars: Int = 0,
    val summaryTotal: Int = 0
) {
    val currentWord: WordItem? get() = deck.getOrNull(currentIndex)
    val currentLogic: LogicPuzzle? get() = logicPuzzles.getOrNull(logicIndex)
}

class FlashcardViewModel : ViewModel() {

    var uiState by mutableStateOf(WordPopUiState())
        private set

    fun toggleReadAloud(): Boolean {
        val next = !uiState.readAloudEnabled
        uiState = uiState.copy(readAloudEnabled = next)
        return next
    }

    fun toggleSlowMode(): Boolean {
        val next = !uiState.slowMode
        uiState = uiState.copy(slowMode = next)
        return next
    }

    fun toggleAutoBilingual() {
        val next = !uiState.autoBilingualVn
        uiState = uiState.copy(autoBilingualVn = next, showVnOnCurrent = next)
    }

    fun toggleVnOnCurrent() {
        uiState = uiState.copy(showVnOnCurrent = !uiState.showVnOnCurrent)
    }

    fun openSettings() {
        if (uiState.screen == ScreenMode.SETTINGS) {
            uiState = uiState.copy(screen = uiState.previousScreen)
        } else {
            uiState = uiState.copy(previousScreen = uiState.screen, screen = ScreenMode.SETTINGS)
        }
    }

    fun closeSettings() {
        uiState = uiState.copy(screen = uiState.previousScreen)
    }

    fun goHome() {
        uiState = uiState.copy(screen = ScreenMode.HOME)
    }

    fun startCategory(category: WordCategory) {
        val shuffledDeck = WordRepository.wordsFor(category).shuffled()
        val firstTarget = shuffledDeck.first()
        uiState = uiState.copy(
            screen = ScreenMode.QUIZ,
            logicMode = null,
            category = category,
            deck = shuffledDeck,
            currentIndex = 0,
            options = buildOptions(category, firstTarget),
            answeredCorrectly = false,
            wrongChoices = emptySet(),
            stars = 0,
            showVnOnCurrent = uiState.autoBilingualVn,
            feedbackText = "What is this? Pick the right word!"
        )
    }

    fun selectOption(chosen: WordItem): String {
        val target = uiState.currentWord ?: return ""
        if (uiState.answeredCorrectly) return chosen.word

        return if (chosen.word == target.word) {
            val earnedStar = uiState.wrongChoices.isEmpty()
            uiState = uiState.copy(
                answeredCorrectly = true,
                stars = if (earnedStar) uiState.stars + 1 else uiState.stars,
                feedbackText = "Yes! ${target.word}! (${target.vnWord})"
            )
            "Great job! ${target.word}! ${target.sentenceEn}"
        } else {
            uiState = uiState.copy(
                wrongChoices = uiState.wrongChoices + chosen.word,
                feedbackText = "That's ${chosen.word} - try again!"
            )
            "${chosen.word}. Try again!"
        }
    }

    fun nextQuestion(): String? {
        val category = uiState.category ?: return null
        val nextIdx = uiState.currentIndex + 1
        return if (nextIdx >= uiState.deck.size) {
            val updatedBest = uiState.bestStars.toMutableMap()
            val prevBest = updatedBest[category] ?: 0
            if (uiState.stars > prevBest) updatedBest[category] = uiState.stars
            val title = "all ${uiState.deck.size} words in ${category.title}"
            uiState = uiState.copy(
                screen = ScreenMode.SUMMARY,
                bestStars = updatedBest,
                summaryTitle = title,
                summaryStars = uiState.stars,
                summaryTotal = uiState.deck.size
            )
            "Awesome job! You finished $title!"
        } else {
            val nextTarget = uiState.deck[nextIdx]
            uiState = uiState.copy(
                currentIndex = nextIdx,
                options = buildOptions(category, nextTarget),
                answeredCorrectly = false,
                wrongChoices = emptySet(),
                showVnOnCurrent = uiState.autoBilingualVn,
                feedbackText = "What is this? Pick the right word!"
            )
            null
        }
    }

    fun startLogicMode(mode: LogicMode): String {
        val allCats = WordCategory.entries
        val puzzles = if (mode == LogicMode.MYSTERY_CLUE) {
            WordRepository.allWords().shuffled().take(10).map { target ->
                val distractors = WordRepository.wordsFor(target.category)
                    .filter { it.word != target.word }
                    .shuffled()
                    .take(3)
                LogicPuzzle(
                    mode = LogicMode.MYSTERY_CLUE,
                    target = target,
                    options = (distractors + target).shuffled()
                )
            }
        } else {
            (0 until 10).map { i ->
                val majCat = allCats[i % allCats.size]
                val oddCat = allCats.filter { it != majCat }.random()
                val trio = WordRepository.wordsFor(majCat).shuffled().take(3)
                val odd = WordRepository.wordsFor(oddCat).random()
                LogicPuzzle(
                    mode = LogicMode.ODD_ONE_OUT,
                    target = odd,
                    options = (trio + odd).shuffled(),
                    majorityCategory = majCat
                )
            }.shuffled()
        }

        val first = puzzles.first()
        uiState = uiState.copy(
            screen = ScreenMode.LOGIC,
            logicMode = mode,
            logicPuzzles = puzzles,
            logicIndex = 0,
            logicAnswered = false,
            logicWrongChoices = emptySet(),
            logicStars = 0,
            showVnOnCurrent = uiState.autoBilingualVn,
            logicFeedback = if (mode == LogicMode.MYSTERY_CLUE) "Who am I? Pick the matching word!" else "Spot the odd one out!"
        )
        return if (mode == LogicMode.MYSTERY_CLUE) first.target.clueEn else "Which one does not belong with the others?"
    }

    fun selectLogicOption(chosen: WordItem): String {
        val p = uiState.currentLogic ?: return ""
        if (uiState.logicAnswered) return chosen.word

        return if (chosen.word == p.target.word) {
            val earnedStar = uiState.logicWrongChoices.isEmpty()
            val msg = if (p.mode == LogicMode.MYSTERY_CLUE) {
                "You solved it! ${p.target.word} (${p.target.vnWord}) - ${p.target.sentenceEn}"
            } else {
                val maj = p.majorityCategory?.title ?: "the others"
                "Smart! ${p.target.word} is in ${p.target.category.title}, while the other 3 are $maj!"
            }
            uiState = uiState.copy(
                logicAnswered = true,
                logicStars = if (earnedStar) uiState.logicStars + 1 else uiState.logicStars,
                logicFeedback = msg
            )
            if (p.mode == LogicMode.MYSTERY_CLUE) {
                "Awesome detective! It's ${p.target.word}! ${p.target.sentenceEn}"
            } else {
                val maj = p.majorityCategory?.title ?: "the others"
                "Smart thinking! ${p.target.word} is in ${p.target.category.title}, while the other three are $maj!"
            }
        } else {
            val hint = if (p.mode == LogicMode.MYSTERY_CLUE) {
                "Not ${chosen.word} - listen to the clue again!"
            } else {
                val maj = p.majorityCategory?.title ?: "the group"
                "${chosen.word} belongs with $maj - find the different one!"
            }
            uiState = uiState.copy(
                logicWrongChoices = uiState.logicWrongChoices + chosen.word,
                logicFeedback = hint
            )
            "${chosen.word}. Try again!"
        }
    }

    fun nextLogicPuzzle(): String {
        val nextIdx = uiState.logicIndex + 1
        val mode = uiState.logicMode ?: LogicMode.MYSTERY_CLUE
        return if (nextIdx >= uiState.logicPuzzles.size) {
            val title = "Logic Play: ${mode.title}"
            uiState = uiState.copy(
                screen = ScreenMode.SUMMARY,
                summaryTitle = title,
                summaryStars = uiState.logicStars,
                summaryTotal = uiState.logicPuzzles.size
            )
            "Awesome job! You got ${uiState.logicStars} stars in $title!"
        } else {
            val nextP = uiState.logicPuzzles[nextIdx]
            uiState = uiState.copy(
                logicIndex = nextIdx,
                logicAnswered = false,
                logicWrongChoices = emptySet(),
                showVnOnCurrent = uiState.autoBilingualVn,
                logicFeedback = if (mode == LogicMode.MYSTERY_CLUE) "Who am I? Pick the matching word!" else "Spot the odd one out!"
            )
            if (mode == LogicMode.MYSTERY_CLUE) nextP.target.clueEn else "Which one does not belong with the others?"
        }
    }

    private fun buildOptions(category: WordCategory, target: WordItem): List<WordItem> {
        val distractors = WordRepository.wordsFor(category)
            .filter { it.word != target.word }
            .shuffled()
            .take(3)
        return (distractors + target).shuffled()
    }
}
