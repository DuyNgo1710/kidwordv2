package com.wordpop.kids.v2.model

import androidx.compose.ui.graphics.Color

data class WordItem(
    val word: String,
    val emoji: String,
    val sentenceEn: String,
    val vnWord: String,
    val clueEn: String,
    val clueVn: String,
    val category: WordCategory
)

enum class WordCategory(
    val title: String,
    val vnTitle: String,
    val icon: String,
    val accentColor: Color,
    val softBgColor: Color
) {
    ANIMALS(
        title = "Animals",
        vnTitle = "Động vật",
        icon = "🦁",
        accentColor = Color(0xFF10B981),
        softBgColor = Color(0xFFECFDF5)
    ),
    VEHICLES(
        title = "Vehicles",
        vnTitle = "Phương tiện",
        icon = "🚀",
        accentColor = Color(0xFF0EA5E9),
        softBgColor = Color(0xFFF0F9FF)
    ),
    FAMILY_STUFF(
        title = "Family Stuff",
        vnTitle = "Đồ dùng gia đình",
        icon = "🏠",
        accentColor = Color(0xFFF43F5E),
        softBgColor = Color(0xFFFFF1F2)
    )
}

enum class LogicMode(val title: String) {
    MYSTERY_CLUE("Mystery Clue"),
    ODD_ONE_OUT("Odd One Out")
}

data class LogicPuzzle(
    val mode: LogicMode,
    val target: WordItem,
    val options: List<WordItem>,
    val majorityCategory: WordCategory? = null
)
