package com.wordpop.kids.v2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.wordpop.kids.v2.audio.TtsManager
import com.wordpop.kids.v2.data.WordRepository
import com.wordpop.kids.v2.model.LogicMode
import com.wordpop.kids.v2.model.WordCategory
import com.wordpop.kids.v2.model.WordItem
import com.wordpop.kids.v2.ui.FlashcardViewModel
import com.wordpop.kids.v2.ui.ScreenMode
import com.wordpop.kids.v2.ui.WordPopUiState

class MainActivity : ComponentActivity() {

    private lateinit var ttsManager: TtsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ttsManager = TtsManager(this)

        setContent {
            MaterialTheme {
                val vm: FlashcardViewModel = viewModel()
                WordPopV2App(
                    state = vm.uiState,
                    onSpeak = { text, force ->
                        if (force || vm.uiState.readAloudEnabled) {
                            ttsManager.speak(text, vm.uiState.slowMode)
                        }
                    },
                    onToggleReadAloud = {
                        val enabled = vm.toggleReadAloud()
                        if (enabled) ttsManager.speak("Read aloud is on", vm.uiState.slowMode)
                        else ttsManager.stop()
                    },
                    onToggleSlowMode = {
                        val slow = vm.toggleSlowMode()
                        ttsManager.speak(if (slow) "Slow voice" else "Normal voice", slow)
                    },
                    onToggleAutoBilingual = { vm.toggleAutoBilingual() },
                    onToggleVnOnCurrent = { vm.toggleVnOnCurrent() },
                    onOpenSettings = { vm.openSettings() },
                    onCloseSettings = { vm.closeSettings() },
                    onSelectCategory = { cat ->
                        vm.startCategory(cat)
                        if (vm.uiState.readAloudEnabled) ttsManager.speak(cat.title, vm.uiState.slowMode)
                    },
                    onSelectOption = { item ->
                        val spoken = vm.selectOption(item)
                        if (vm.uiState.readAloudEnabled && spoken.isNotEmpty()) {
                            ttsManager.speak(spoken, vm.uiState.slowMode)
                        }
                    },
                    onNextQuestion = {
                        val summarySpeech = vm.nextQuestion()
                        if (summarySpeech != null && vm.uiState.readAloudEnabled) {
                            ttsManager.speak(summarySpeech, vm.uiState.slowMode)
                        }
                    },
                    onStartLogic = { mode ->
                        val clueSpeech = vm.startLogicMode(mode)
                        if (vm.uiState.readAloudEnabled) ttsManager.speak(clueSpeech, vm.uiState.slowMode)
                    },
                    onSelectLogicOption = { item ->
                        val spoken = vm.selectLogicOption(item)
                        if (vm.uiState.readAloudEnabled && spoken.isNotEmpty()) {
                            ttsManager.speak(spoken, vm.uiState.slowMode)
                        }
                    },
                    onNextLogic = {
                        val nextSpeech = vm.nextLogicPuzzle()
                        if (vm.uiState.readAloudEnabled && nextSpeech.isNotEmpty()) {
                            ttsManager.speak(nextSpeech, vm.uiState.slowMode)
                        }
                    },
                    onGoHome = {
                        ttsManager.stop()
                        vm.goHome()
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ttsManager.shutdown()
    }
}

@Composable
fun WordPopV2App(
    state: WordPopUiState,
    onSpeak: (String, Boolean) -> Unit,
    onToggleReadAloud: () -> Unit,
    onToggleSlowMode: () -> Unit,
    onToggleAutoBilingual: () -> Unit,
    onToggleVnOnCurrent: () -> Unit,
    onOpenSettings: () -> Unit,
    onCloseSettings: () -> Unit,
    onSelectCategory: (WordCategory) -> Unit,
    onSelectOption: (WordItem) -> Unit,
    onNextQuestion: () -> Unit,
    onStartLogic: (LogicMode) -> Unit,
    onSelectLogicOption: (WordItem) -> Unit,
    onNextLogic: () -> Unit,
    onGoHome: () -> Unit
) {
    val bgBrush = Brush.verticalGradient(
        colors = listOf(Color(0xFFFEF9C3), Color(0xFFE0F2FE), Color(0xFFFCE7F3))
    )

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0284C7))
                    .statusBarsPadding()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (state.screen != ScreenMode.HOME) {
                    TextButton(
                        onClick = onGoHome,
                        colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
                    ) {
                        Text("← Home", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.wordpop_logo),
                            contentDescription = "WordPop! Kids v2 logo",
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                        )
                        Column {
                            Text("WordPop! Kids", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Text("Version 2.0", color = Color(0xFFBAE6FD), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = onToggleReadAloud,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.readAloudEnabled) Color(0xFFFBBF24) else Color.White.copy(alpha = 0.22f),
                            contentColor = if (state.readAloudEnabled) Color(0xFF0F172A) else Color.White
                        )
                    ) {
                        Text(if (state.readAloudEnabled) "🔊 ON" else "🔇 OFF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.22f))
                    ) {
                        Text("⚙️", fontSize = 18.sp)
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(bgBrush)
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            when (state.screen) {
                ScreenMode.HOME -> HomeScreen(
                    bestStars = state.bestStars,
                    onSelectCategory = onSelectCategory,
                    onSpeakCategory = { cat -> onSpeak(cat.title, true) },
                    onStartLogic = onStartLogic
                )
                ScreenMode.QUIZ -> QuizScreen(
                    state = state,
                    onSpeakText = { text -> onSpeak(text, true) },
                    onToggleVn = onToggleVnOnCurrent,
                    onSelectOption = onSelectOption,
                    onNext = onNextQuestion
                )
                ScreenMode.LOGIC -> LogicScreen(
                    state = state,
                    onSpeakText = { text -> onSpeak(text, true) },
                    onToggleVn = onToggleVnOnCurrent,
                    onSelectOption = onSelectLogicOption,
                    onNext = onNextLogic
                )
                ScreenMode.SETTINGS -> SettingsScreen(
                    state = state,
                    onToggleReadAloud = onToggleReadAloud,
                    onToggleSlowMode = onToggleSlowMode,
                    onToggleAutoBilingual = onToggleAutoBilingual,
                    onClose = onCloseSettings
                )
                ScreenMode.SUMMARY -> SummaryScreen(
                    state = state,
                    onSpeakSummary = {
                        onSpeak("Awesome job! You got ${state.summaryStars} stars in ${state.summaryTitle}!", true)
                    },
                    onPlayAgain = {
                        val lm = state.logicMode
                        if (lm != null) onStartLogic(lm)
                        else state.category?.let(onSelectCategory)
                    },
                    onGoHome = onGoHome
                )
            }
        }
    }
}

@Composable
fun HomeScreen(
    bestStars: Map<WordCategory, Int>,
    onSelectCategory: (WordCategory) -> Unit,
    onSpeakCategory: (WordCategory) -> Unit,
    onStartLogic: (LogicMode) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.White.copy(alpha = 0.9f),
            border = BorderStroke(2.dp, Color(0xFFBAE6FD))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.wordpop_logo),
                    contentDescription = "WordPop mascot",
                    modifier = Modifier.size(56.dp).clip(RoundedCornerShape(16.dp))
                )
                Column {
                    Text("Pick a World to Play!", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E293B))
                    Text("60 words • Full sentences • Logic Play", fontSize = 12.sp, color = Color(0xFF64748B))
                }
            }
        }

        WordCategory.entries.forEach { cat ->
            val total = WordRepository.wordsFor(cat).size
            val best = bestStars[cat] ?: 0
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onSelectCategory(cat) },
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = cat.accentColor),
                elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Box(
                            modifier = Modifier.size(54.dp).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(cat.icon, fontSize = 30.sp)
                        }
                        Column {
                            Text(cat.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("$total words  •  ⭐ $best / $total", fontSize = 13.sp, color = Color(0xFFFEF3C7), fontWeight = FontWeight.SemiBold)
                        }
                    }

                    IconButton(
                        onClick = { onSpeakCategory(cat) },
                        modifier = Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f))
                    ) {
                        Text("🔊", fontSize = 18.sp)
                    }
                }
            }
        }

        // 4th Card: Logic Play Mini-Mode
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF8B5CF6)),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier = Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🧩", fontSize = 28.sp)
                    }
                    Column {
                        Text("Logic Play  ★ NEW v2", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text("Riddles & Odd One Out (Ages 6-8)", fontSize = 12.sp, color = Color(0xFFEDE9FE))
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { onStartLogic(LogicMode.MYSTERY_CLUE) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF6D28D9))
                    ) {
                        Text("🕵️ Mystery Clue", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Button(
                        onClick = { onStartLogic(LogicMode.ODD_ONE_OUT) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFFA21CAF))
                    ) {
                        Text("🔎 Odd One Out", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun QuizScreen(
    state: WordPopUiState,
    onSpeakText: (String) -> Unit,
    onToggleVn: () -> Unit,
    onSelectOption: (WordItem) -> Unit,
    onNext: () -> Unit
) {
    val category = state.category ?: return
    val target = state.currentWord ?: return

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${category.icon} ${category.title} • ${state.currentIndex + 1}/${state.deck.size}",
                fontWeight = FontWeight.Bold,
                color = Color(0xFF334155),
                fontSize = 14.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                FilledTonalButton(
                    onClick = onToggleVn,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = Color(0xFFFFE4E6),
                        contentColor = Color(0xFFBE123C)
                    )
                ) {
                    Text("🇻🇳 VN Hint", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Surface(shape = RoundedCornerShape(50), color = Color(0xFFFEF3C7)) {
                    Text("⭐ ${state.stars}", modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), fontWeight = FontWeight.Bold, color = Color(0xFF92400E), fontSize = 13.sp)
                }
            }
        }

        LinearProgressIndicator(
            progress = { (state.currentIndex + 1).toFloat() / state.deck.size.toFloat() },
            modifier = Modifier.fillMaxWidth().height(9.dp).clip(RoundedCornerShape(50)),
            color = category.accentColor,
            trackColor = Color.White
        )

        Card(
            modifier = Modifier.fillMaxWidth().clickable { onSpeakText(target.word) },
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(3.dp, category.accentColor.copy(alpha = 0.35f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp, horizontal = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(target.emoji, fontSize = 78.sp)
                if (state.showVnOnCurrent) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFFFFF1F2), border = BorderStroke(1.dp, Color(0xFFFECDD3))) {
                        Text(
                            text = "🇻🇳 ${target.vnWord} — ${target.clueVn}",
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF9F1239),
                            textAlign = TextAlign.Center
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { onSpeakText(target.word) },
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0EA5E9))
                ) {
                    Text("🔊 Hear Word", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }

        // Feedback & Full-Sentence Echo
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (state.answeredCorrectly) Color(0xFFECFDF5) else Color.White.copy(alpha = 0.85f),
            border = BorderStroke(1.dp, if (state.answeredCorrectly) Color(0xFFA7F3D0) else Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = state.feedbackText,
                    textAlign = TextAlign.Center,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (state.answeredCorrectly) Color(0xFF047857) else Color(0xFF475569)
                )
                if (state.answeredCorrectly) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "“${target.sentenceEn}”",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF065F46),
                            modifier = Modifier.weight(1f, fill = false),
                            textAlign = TextAlign.Center
                        )
                        IconButton(
                            onClick = { onSpeakText(target.sentenceEn) },
                            modifier = Modifier.size(30.dp).clip(CircleShape).background(Color(0xFFD1FAE5))
                        ) {
                            Text("🔊", fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // 4 Options
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            state.options.chunked(2).forEach { rowItems ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    rowItems.forEach { opt ->
                        val isCorrectShown = state.answeredCorrectly && opt.word == target.word
                        val isWrong = opt.word in state.wrongChoices
                        val bg = when {
                            isCorrectShown -> Color(0xFF10B981)
                            isWrong -> Color(0xFFFFF1F2)
                            else -> Color.White
                        }
                        val fg = when {
                            isCorrectShown -> Color.White
                            isWrong -> Color(0xFFE11D48)
                            else -> Color(0xFF1E293B)
                        }
                        Surface(
                            modifier = Modifier.weight(1f).height(66.dp).clickable { onSelectOption(opt) },
                            shape = RoundedCornerShape(18.dp),
                            color = bg,
                            border = BorderStroke(2.dp, if (isCorrectShown) Color(0xFF059669) else if (isWrong) Color(0xFFFDA4AF) else Color(0xFFE2E8F0)),
                            shadowElevation = 2.dp
                        ) {
                            Row(
                                modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(opt.word, color = fg, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                                IconButton(
                                    onClick = { onSpeakText(opt.word) },
                                    modifier = Modifier.size(34.dp).clip(CircleShape).background(Color(0xFFE0F2FE))
                                ) {
                                    Text("🔊", fontSize = 14.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        if (state.answeredCorrectly) {
            Spacer(modifier = Modifier.weight(1f))
            Button(
                onClick = onNext,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
            ) {
                Text(
                    text = if (state.currentIndex == state.deck.size - 1) "See My Stars! 🏆" else "Next Word →",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun LogicScreen(
    state: WordPopUiState,
    onSpeakText: (String) -> Unit,
    onToggleVn: () -> Unit,
    onSelectOption: (WordItem) -> Unit,
    onNext: () -> Unit
) {
    val puzzle = state.currentLogic ?: return
    val isMystery = puzzle.mode == LogicMode.MYSTERY_CLUE

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${if (isMystery) "🕵️ Mystery Clue" else "🔎 Odd One Out"} • ${state.logicIndex + 1}/${state.logicPuzzles.size}",
                fontWeight = FontWeight.Bold,
                color = Color(0xFF5B21B6),
                fontSize = 14.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                FilledTonalButton(
                    onClick = onToggleVn,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFFFE4E6), contentColor = Color(0xFFBE123C))
                ) {
                    Text("🇻🇳 VN Clue", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Surface(shape = RoundedCornerShape(50), color = Color(0xFFFEF3C7)) {
                    Text("⭐ ${state.logicStars}", modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), fontWeight = FontWeight.Bold, color = Color(0xFF92400E), fontSize = 13.sp)
                }
            }
        }

        LinearProgressIndicator(
            progress = { (state.logicIndex + 1).toFloat() / state.logicPuzzles.size.toFloat() },
            modifier = Modifier.fillMaxWidth().height(9.dp).clip(RoundedCornerShape(50)),
            color = Color(0xFF8B5CF6),
            trackColor = Color.White
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(3.dp, Color(0xFFDDD6FE)),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (state.logicAnswered) puzzle.target.emoji else if (isMystery) "❓" else "🔎",
                    fontSize = 62.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (isMystery) "“${puzzle.target.clueEn}”" else "Which one does NOT belong with the others?",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B),
                    textAlign = TextAlign.Center
                )
                if (state.showVnOnCurrent) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFFFFF1F2), border = BorderStroke(1.dp, Color(0xFFFECDD3))) {
                        Text(
                            text = if (isMystery) "🇻🇳 ${puzzle.target.clueVn}" else "🇻🇳 Hình nào KHÔNG cùng nhóm với 3 hình còn lại?",
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF9F1239),
                            textAlign = TextAlign.Center
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        onSpeakText(if (isMystery) puzzle.target.clueEn else "Which one does not belong with the others?")
                    },
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED))
                ) {
                    Text("🔊 Hear Clue", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (state.logicAnswered) Color(0xFFECFDF5) else Color.White.copy(alpha = 0.85f),
            border = BorderStroke(1.dp, if (state.logicAnswered) Color(0xFFA7F3D0) else Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = state.logicFeedback,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                textAlign = TextAlign.Center,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = if (state.logicAnswered) Color(0xFF047857) else Color(0xFF475569)
            )
        }

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            puzzle.options.chunked(2).forEach { rowItems ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    rowItems.forEach { opt ->
                        val isCorrectShown = state.logicAnswered && opt.word == puzzle.target.word
                        val isWrong = opt.word in state.logicWrongChoices
                        val bg = when {
                            isCorrectShown -> Color(0xFF10B981)
                            isWrong -> Color(0xFFFFF1F2)
                            else -> Color.White
                        }
                        val fg = when {
                            isCorrectShown -> Color.White
                            isWrong -> Color(0xFFE11D48)
                            else -> Color(0xFF1E293B)
                        }
                        Surface(
                            modifier = Modifier.weight(1f).height(68.dp).clickable { onSelectOption(opt) },
                            shape = RoundedCornerShape(18.dp),
                            color = bg,
                            border = BorderStroke(2.dp, if (isCorrectShown) Color(0xFF059669) else if (isWrong) Color(0xFFFDA4AF) else Color(0xFFE2E8F0)),
                            shadowElevation = 2.dp
                        ) {
                            Row(
                                modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (isMystery) opt.word else "${opt.emoji} ${opt.word}",
                                    color = fg,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { onSpeakText(opt.word) },
                                    modifier = Modifier.size(34.dp).clip(CircleShape).background(Color(0xFFEDE9FE))
                                ) {
                                    Text("🔊", fontSize = 14.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        if (state.logicAnswered) {
            Spacer(modifier = Modifier.weight(1f))
            Button(
                onClick = onNext,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED))
            ) {
                Text(
                    text = if (state.logicIndex == state.logicPuzzles.size - 1) "See My Stars! 🏆" else "Next Puzzle →",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun SettingsScreen(
    state: WordPopUiState,
    onToggleReadAloud: () -> Unit,
    onToggleSlowMode: () -> Unit,
    onToggleAutoBilingual: () -> Unit,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Image(
                painter = painterResource(id = R.drawable.wordpop_logo),
                contentDescription = "WordPop! Kids v2 logo",
                modifier = Modifier.size(56.dp).clip(RoundedCornerShape(16.dp))
            )
            Column {
                Text("WordPop! Kids v2", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E293B))
                Text("Package: com.wordpop.kids.v2", fontSize = 12.sp, color = Color(0xFF64748B))
            }
        }

        Text("LEARNING PREFERENCES", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))

        SettingRow("🔊 Read Aloud", "Speak words, clues, and sentences", if (state.readAloudEnabled) "ON" else "OFF", state.readAloudEnabled, onToggleReadAloud)
        SettingRow("🐢 Voice Speed", "Slower voice is easier for 6-year-olds", if (state.slowMode) "Slow" else "Normal", state.slowMode, onToggleSlowMode)
        SettingRow("🇻🇳 Vietnamese Bilingual Bridge", "Auto-show Vietnamese hints & classifiers", if (state.autoBilingualVn) "ON" else "OFF", state.autoBilingualVn, onToggleAutoBilingual)

        Text("VERSION HISTORY & WHAT'S NEW", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))

        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFEEF2FF)),
            border = BorderStroke(2.dp, Color(0xFFC7D2FE))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Version 2.0 (Current)", fontWeight = FontWeight.ExtraBold, color = Color(0xFF312E81), fontSize = 15.sp)
                Text("• Cute new mascot logo & app icon", fontSize = 13.sp, color = Color(0xFF3730A3))
                Text("• Settings screen with version history & preferences", fontSize = 13.sp, color = Color(0xFF3730A3))
                Text("• Full-Sentence Echo + optional Vietnamese bilingual hints", fontSize = 13.sp, color = Color(0xFF3730A3))
                Text("• Logic Play mini-mode: Mystery Clue & Odd One Out", fontSize = 13.sp, color = Color(0xFF3730A3))
                Text("• Side-by-side install (com.wordpop.kids.v2) so v1 stays intact", fontSize = 13.sp, color = Color(0xFF3730A3))
            }
        }

        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Version 1.0", fontWeight = FontWeight.Bold, color = Color(0xFF334155), fontSize = 14.sp)
                Text("• 60 simple English words across Animals, Vehicles, and Family Stuff", fontSize = 12.sp, color = Color(0xFF64748B))
                Text("• 4-choice picture flashcards with per-action Read Aloud", fontSize = 12.sp, color = Color(0xFF64748B))
            }
        }

        Button(
            onClick = onClose,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
        ) {
            Text("Done", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, badge: String, active: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1E293B))
                Text(subtitle, fontSize = 11.sp, color = Color(0xFF64748B))
            }
            Button(
                onClick = onClick,
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (active) Color(0xFF10B981) else Color(0xFFE2E8F0),
                    contentColor = if (active) Color.White else Color(0xFF475569)
                )
            ) {
                Text(badge, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun SummaryScreen(
    state: WordPopUiState,
    onSpeakSummary: () -> Unit,
    onPlayAgain: () -> Unit,
    onGoHome: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🏆", fontSize = 74.sp)
        Spacer(modifier = Modifier.height(10.dp))
        Text("Awesome Job!", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E293B))
        Spacer(modifier = Modifier.height(6.dp))
        Text("You finished ${state.summaryTitle}!", fontSize = 15.sp, color = Color(0xFF475569), textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.height(18.dp))

        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7))) {
            Column(modifier = Modifier.padding(horizontal = 32.dp, vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("⭐ ${state.summaryStars} / ${state.summaryTotal}", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFB45309))
                Text("First-Try Stars", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
            }
        }

        Spacer(modifier = Modifier.height(14.dp))
        OutlinedButton(onClick = onSpeakSummary, shape = RoundedCornerShape(50)) {
            Text("🔊 Hear Celebration", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(22.dp))
        Button(
            onClick = onPlayAgain,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
        ) {
            Text("🔄 Play Again", fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(10.dp))
        FilledTonalButton(
            onClick = onGoHome,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text("🏠 Back to Home", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}
