# WordPop! Kids v2 (Android)

An upgraded kid-friendly bilingual English flashcard & logic app for ages 6-8, registered under a separate package ID (`com.wordpop.kids.v2`) so you can keep **WordPop! Kids v1** installed side-by-side on your Android phone.

## What's New in v2.0
- **Cute Mascot App Logo:** Custom launcher icon and in-app mascot header.
- **Settings & Version History:** Gear icon (`⚙️`) to toggle Read Aloud, Voice Speed, Vietnamese Bilingual Bridge, and inspect the v1.0 → v2.0 changelog.
- **Full-Sentence Echo + Vietnamese Bilingual Bridge:** Speaks a complete English sentence on every match, plus an optional `🇻🇳 VN Hint` toggle showing natural Vietnamese classifiers and clues.
- **Logic Play Mini-Mode:** Two new reasoning games using all 60 words — **Mystery Clue** riddles and **Odd One Out** puzzles.
- **Improved TTS Queue:** Queues speech on cold start so the first tap is never dropped.

## Build APK via GitHub Actions
Upload `WordPopKidsV2Android.zip` to GitHub (or unzip and push) and run the workflow `.github/workflows/build-apk.yml` to download `WordPop-Kids-v2-APK`.
